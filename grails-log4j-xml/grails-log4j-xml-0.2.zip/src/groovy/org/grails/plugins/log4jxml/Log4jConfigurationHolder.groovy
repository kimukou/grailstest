package org.grails.plugins.log4jxml

public class Log4jConfigurationHolder {
  static log4j = [:]
  static boolean enabled = false
}