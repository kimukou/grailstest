package com.odelia.grails.plugins.atmosphere;

import org.codehaus.groovy.grails.commons.InjectableGrailsClass;


/**
 *
 * @author BGoetzmann
 */
public interface GrailsAtmosphereHandlerClass extends InjectableGrailsClass {

}
