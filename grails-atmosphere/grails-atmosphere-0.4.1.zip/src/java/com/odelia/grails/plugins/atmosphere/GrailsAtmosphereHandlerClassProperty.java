package com.odelia.grails.plugins.atmosphere;


/**
 *
 * @author BGoetzmann
 */
public interface GrailsAtmosphereHandlerClassProperty {

}
